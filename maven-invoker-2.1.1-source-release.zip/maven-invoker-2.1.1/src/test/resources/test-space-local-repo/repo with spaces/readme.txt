Dummy file used to ensure the repo directory is copied over to target/test-classes.
